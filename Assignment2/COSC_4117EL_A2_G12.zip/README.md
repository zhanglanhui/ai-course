# Warehouse Robot Decision Making

### CPSC-4117EL-01 · Artificial Intelligence · Assignment 2

This Assignment implements and evaluates **Value Iteration (VI)** and **tabular Q-Learning (QL)** for the warehouse
pickup–delivery–return task. Both approaches use the instructor-provided `warehouse_gridworld_domain_random.py`
framework. VI plans with a known transition model; Q-Learning learns from sampled interaction without receiving
transition probabilities.

## 1. Environment and task

The robot starts at the charging dock, collects a package, delivers it to the packing station, and returns to the dock.
Shelves block movement; congestion cells incur penalties. An episode ends after successful return or at the
environment's step limit.

The common task state is `(row, col, has_package, delivered)`. Position alone cannot describe whether the robot should
collect, deliver, or return. The state thus distinguishes the three task stages.

| Setting                         | Value                                    |
|---------------------------------|------------------------------------------|
| Grid                            | 10 × 10                                  |
| Fixed layout seed               | `42`                                     |
| Pickup                          | `(2, 2)`                                 |
| Packing station                 | `(0, 4)`                                 |
| Charging dock                   | `(6, 0)`                                 |
| Maximum episode length          | `120` steps                              |
| Intended-action probability `p` | `1.00`, `0.90`, `0.80`                   |
| Other motion outcomes           | Perpendicular directions, each `(1-p)/2` |

Coordinates are `(row, column)` for layout seed 42. If an attempted movement hits a shelf or boundary, the original
environment handles the resulting transition and reward.

**Framework preservation.** `warehouse_gridworld_domain_random.py` is the instructor environment. The Q-Learning README
documents one compatibility modification: guarding `import pygame` with `try/except ImportError` to permit headless
execution. `warehouse_bridge.py` adds the assignment's stochastic motion sampling and delegates the resulting action to
the original `world.step(...)`; it is not a replacement simulator. The final team should use **one consistent copy** of
the environment and confirm that both algorithms work with it.

## 2. Project layout

The following is the **intended final submission layout**. It combines the files described by the two original READMEs;
it does not imply that all listed files were supplied or independently verified here.

```text
COSC_4117EL_A2_G12/
├── README.md
├── warehouse_gridworld_domain_random.py
├── warehouse_bridge.py
├── COSC_4117EL_A2_G12-value_iteration.py
├── COSC_4117EL_A2_G12-q_learning.py
├── plot_policies.py
├── compare_policies.py
├── Assignment2_Report.pdf
├── value_iteration_results/
│   ├── value_iteration_results.csv
│   ├── value_iteration_policy_p_*.png
│   ├── policy_action_changes.txt
│   └── run_summary.txt
└── results_q_learning/
    └── [CSV metrics, policy JSONs, visitation JSONs, rollout data and PNG plots]
```

## 3. Installation

Use **Python 3.10 or newer**. From the project directory:

```bash
python -m pip install numpy matplotlib
```

`pygame` is required only for the original interactive GUI, according to the source READMEs. Neither algorithm should
require Gymnasium. If you want to launch the original GUI, install `pygame` separately.

All commands below assume the scripts and instructor environment are in the same project directory.

## 4. Reproduce the experiments

### 4.1 Value Iteration

```bash
python value_iteration.py
```

The script generates its outputs under `value_iteration_results/`.

The documented VI configuration uses `gamma = 0.95`, convergence tolerance `theta = 1e-6`, and **500 evaluation episodes
per probability setting**. Its output includes convergence/evaluation metrics, three-stage policy maps, and examples of
action changes under increasing uncertainty.

### 4.2 Q-Learning

```bash
python q_learning.py --episodes 5000 --eval-episodes 100 --max-steps 120 --seeds 11 42 99 --probabilities 1.0 0.9 0.8 --output results_q_learning
```

The documented QL run trains for **5,000 episodes**, evaluates over **100 episodes**, and uses random seeds **11, 42,
and 99**. It includes two hyperparameter configurations and epsilon-greedy exploration with decay. The fixed layout seed
is distinct from the training/motion seeds. The agent does **not** receive `p` as an input; only the environment adapter
uses it to generate stochastic transitions.

After the Q-Learning run has produced its outputs:

```bash
python plot_policies.py
```

To compare two example learned policies:

```bash
python compare_policies.py results_q_learning/policy_A_fast_decay_p1.00_seed11.json results_q_learning/policy_A_fast_decay_p0.80_seed11.json --output results_q_learning/changed_actions.csv
```

## 5. How to interpret and compare results

The experiments study how transition uncertainty affects the warehouse policy and task performance.

| Dimension                            | Value Iteration                                            | Q-Learning                                                 |
|--------------------------------------|------------------------------------------------------------|------------------------------------------------------------|
| Learning/planning mechanism          | Bellman updates over a known model                         | Sample-based Q-value updates                               |
| Transition probabilities             | Explicitly known                                           | Hidden from the agent                                      |
| Core reported results                | Iterations to convergence, policy maps, evaluation metrics | Episode reward, success, training behaviour, greedy policy |
| Motion settings                      | `p = 1.00, 0.90, 0.80`                                     | `p = 1.00, 0.90, 0.80`                                     |
| Evaluation count in original READMEs | 500 per `p`                                                | 100 per run                                                |

## 6. Generative AI acknowledgment

- **Value Iteration:** the original VI README supplies this conversation
  link: https://chatgpt.com/share/6aef6e1b-27c8-83ea-ad80-a71f47888e9a
- **Q-Learning:** the original VI README supplies this conversation
  link: https://chatgpt.com/share/6aef6095-5a6c-83ea-a53f-07abde8c9a5f

